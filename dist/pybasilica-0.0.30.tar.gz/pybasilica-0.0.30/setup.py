from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name = "pybasilica",
    version = "0.0.30",
    author = "Azad Sadr",
    author_email= "azad.sadr.h@gmail.com",
    description = "a bayesian model to extract mutational signatures",
    long_description = long_description,
    long_description_content_type = "text/markdown",
    url = "https://github.com/caravagnalab/pybasilica",
    #package_dir = {"":"src"},
    packages = find_packages(),
    python_requires=">=3.9",
    install_requires = [
        "pandas",
        "pyro-api",
        "pyro-ppl",
        "numpy",
        ],
)