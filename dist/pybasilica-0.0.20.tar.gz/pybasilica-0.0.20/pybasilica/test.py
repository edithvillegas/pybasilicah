from pybasilica.main import pyfit
import pandas as pd


M = pd.read_csv("/home/azad/Documents/thesis/SigPhylo/data/real/data_sigphylo.csv")
B_input = pd.read_csv("/home/azad/Documents/thesis/SigPhylo/data/real/beta_aging.csv", index_col=0)
cosmic_df = pd.read_csv("/home/azad/Documents/thesis/SigPhylo/data/cosmic/cosmic_catalogue.csv", index_col=0)

print("M:\n", M)
print("B_input:\n", B_input)
print("cosmic_df:\n", cosmic_df)

'''
output = pyfit(
    M, 
    B_input, 
    k_list=[0, 1, 2, 3, 4, 5, 6], 
    cosmic_df=cosmic_df, 
    lr=0.05, 
    steps_per_iter=500, 
    fixedLimit=0.05, 
    denovoLimit=0.9
    )
'''




