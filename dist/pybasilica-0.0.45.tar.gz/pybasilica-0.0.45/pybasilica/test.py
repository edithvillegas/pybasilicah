import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import random
from main import pyfit
from simulation import input_generator


'''
python setup.py sdist
twine upload --repository testpypi dist/pybasilica-0.0.19.tar.gz
pip install -i https://test.pypi.org/simple/ pybasilica==0.0.18
'''

'''
#===============================================================================
#			OOP
#===============================================================================

class pybasilica:
	def __init__(self, dataset, groups, input_catalogue, reference_catalogue, k, lr, steps, phi, delta):
		self.dataset = dataset
		self.groups = groups
		self.input_catalogue = input_catalogue
		self.reference_catalogue = reference_catalogue
		self.k = k
		self.lr=lr
		self.steps = steps
		self.phi = phi
		self.delta = delta

		self.exposure = None
		self.fixed_signatures = None
		self.denovo_signatures = None
		self.cosine_matrix = None
		
		self._theta = np.sum(dataset.values, axis=1)
		self._num_samples = dataset.size()[0]
		
		self._set_parameters()
		
	
	def _set_parameters(self):
		if self.input_catalogue is None:
            self._k = 0
		else:
            self._beta_fixed = self.input_catalogue
            self._k_fixed = self.input_catalogue.size()[0]
        
        #self._k_denovo = k_denovo

		return 0
		
	def fit(self):
		return 0



#pyfit(M, groups, input_catalogue, reference_catalogue, k, lr, steps, phi, delta)

'''

'''
M = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/data_sigphylo.csv")
B_input = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/beta_aging.csv", index_col=0)
groups = [0,0,1,2,1]
k_list = [0,1,2,3,4,5,6]
cosmic_df = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/cosmic/cosmic_catalogue.csv", index_col=0)
lr = 0.05
steps_per_iter = 500
fixedLimit = 0.05
denovoLimit = 0.9


A_inf_df, B_inf_fixed_df, B_inf_denovo_df = pyfit(
    M=M, 
    groups=None, 
    input_catalogue=B_input, 
    reference_catalogue=cosmic_df, 
    k=k_list, 
    lr=lr, 
    steps=steps_per_iter, 
    phi=fixedLimit, 
    delta=denovoLimit, 
    )


print("A_inf_df\n", A_inf_df)
print("B_inf_fixed_df\n", B_inf_fixed_df)
print("B_inf_denovo_df\n", B_inf_denovo_df)
'''

cosmic_path = "/home/azad/Documents/thesis/pybasilica/pybasilica/data/cosmic/cosmic_catalogue.csv"
#a = input_generator(cosmic_path, target_complexity='low', input_complexity='low', num_samples=10, seed=99)

#print("M :\n", a["M"])
#print("alpha :\n", a["alpha"])
#print("beta_fixed :\n", a["beta_fixed"])
#print("beta_denovo :\n", a["beta_denovo"])
#print("beta_input :\n", a["beta_input"])
#print("cosmic_df :\n", a["cosmic_df"])

print(int(0))


