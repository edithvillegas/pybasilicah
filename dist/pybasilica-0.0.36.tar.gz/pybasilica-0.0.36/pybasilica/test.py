import numpy as np
import pandas as pd

#from pybasilica import pyfit
from main import pyfit


'''
python setup.py sdist
twine upload --repository testpypi dist/pybasilica-0.0.19.tar.gz
pip install -i https://test.pypi.org/simple/ pybasilica==0.0.18
'''

'''
#===============================================================================
#			OOP
#===============================================================================

class pybasilica:
	def __init__(self, dataset, input_catalog, k_list, reference_catalog, lr, steps_per_iter, fixedLimit, denovoLimit, groups):
		self.dataset = dataset
		self.input_catalog = input_catalog
		self.k_list
		self.reference_catalog = reference_catalog
		self.lr
		self.steps_per_iter
		self.fixedLimit
		self.denovoLimit
		self.groups
		
		self._theta = np.sum(dataset.values, axis=1)
		self._num_samples = dataset.size()[0]
		
		self._set_parameters()
		
	
	def _set_parameters(self):
		if self.input_catalog is None:
            self._k_fixed = 0
        else:
            self._beta_fixed = self.input_catalog
            self._k_fixed = self.input_catalog.size()[0]
        
        self._k_denovo = k_denovo

		return 0
		
	def fit(self):
		return 0


pybasilica(x, input_catalog, k_list, reference_catalog, lr, steps_per_iter, fixedLimit, denovoLimit, groups)

'''


M = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/data_sigphylo.csv")
B_input = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/beta_aging.csv", index_col=0)
groups = [0, 0, 1, 0, 2]
k_list = [0,1,2,3,4,5,6]
cosmic_df = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/cosmic/cosmic_catalogue.csv", index_col=0)
lr = 0.05
steps_per_iter = 500
fixedLimit = 0.05
denovoLimit = 0.9

#print("M:\n", M)
#print("B_input:\n", B_input)
#print("cosmic_df:\n", cosmic_df)

A_inf_df, B_inf_fixed_df, B_inf_denovo_df = pyfit(
    M=M, 
	groups=groups,
	B_input=B_input, 
    k=k_list, 
    cosmic_df=cosmic_df, 
    lr=lr, 
    steps=steps_per_iter, 
    phi=fixedLimit, 
    delta=denovoLimit,
    )


print("A_inf_df\n", A_inf_df)
print("B_inf_fixed_df\n", B_inf_fixed_df)
print("B_inf_denovo_df\n", B_inf_denovo_df)

