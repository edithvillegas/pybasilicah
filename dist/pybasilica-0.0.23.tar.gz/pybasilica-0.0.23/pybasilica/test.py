import main
import pandas as pd

'''
python setup.py sdist
twine upload --repository testpypi dist/pybasilica-0.0.19.tar.gz
pip install -i https://test.pypi.org/simple/ pybasilica==0.0.18
'''

'''
M = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/data_sigphylo.csv")
B_input = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/real/beta_aging.csv", index_col=0)
groups = [0, 0, 1, 0, 2]
#groups = None
k_list = [0,1,2,3,4,5,6]
cosmic_df = pd.read_csv("/home/azad/Documents/thesis/pybasilica/pybasilica/data/cosmic/cosmic_catalogue.csv", index_col=0)
lr = 0.05
steps_per_iter = 500
fixedLimit = 0.05
denovoLimit = 0.9

#print("M:\n", M)
#print("B_input:\n", B_input)
#print("cosmic_df:\n", cosmic_df)

A_inf_df, B_inf_fixed_df, B_inf_denovo_df = main.pyfit(
    M, 
    B_input, 
    k_list, 
    cosmic_df, 
    lr, 
    steps_per_iter, 
    fixedLimit, 
    denovoLimit,
    groups=groups
    )


print("A_inf_df\n", A_inf_df)
print("B_inf_fixed_df\n", B_inf_fixed_df)
print("B_inf_denovo_df\n", B_inf_denovo_df)


'''

import torch
import pyro.distributions as dist
import pyro

alpha_tissues = dist.Normal(torch.zeros(5, 2 + 1), 1).sample()
print(alpha_tissues)

groups = [0, 0, 1, 0, 2]

alpha = pyro.sample("activities", dist.Normal(alpha_tissues[groups, :], 1))

print(alpha)